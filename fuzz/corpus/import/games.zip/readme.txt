Not a PGN file: left out by the import.
